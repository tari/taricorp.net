﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace gcnclientGUI
{
    public partial class Form1 : Form
    {
        private string commandLine = "";
        private Process gcnProcess = null;

        public Form1()
        {
            InitializeComponent();
            UpdateCmdLine(null, null);
        }

        private void UpdateCmdLine(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(String.Format("-n {0} ", tb_Hub.Text));
            sb.Append(String.Format("-l {0} ", tb_Name.Text));
            if (cb_Retry.Checked)
                sb.Append("-r ");

            sb.Append(String.Format("-d {0} ", TranslateDevice()));
            tb_Port.Enabled = TranslateDevice() == "arduino";
            if (tb_Port.Enabled)
                sb.Append(String.Format("-c {0} ", tb_Port.Text));

            if (tb_Server.Text != String.Empty)
                sb.Append(String.Format("-s {0} ", tb_Server.Text));

            if (tb_ServerPort.Text != String.Empty)
                sb.Append(String.Format("-p {0} ", tb_ServerPort.Text));

            commandLine = sb.ToString();
            cmdLine.Text = "gcnclient " + commandLine;

            bool acceptableToStart = tb_Hub.Text != String.Empty &&
                                     tb_Name.Text != String.Empty &&
                                     TranslateDevice() != String.Empty &&
                                     gcnProcess == null;
            if (TranslateDevice() == "arduino")
                acceptableToStart &= tb_Port.Text != String.Empty;
            btn_Start.Enabled = acceptableToStart;
        }

        private string TranslateDevice()
        {
            string[] indices = {"direct", "arduino", "usbhid"};
            if (tb_Device.SelectedIndex >= 0 && tb_Device.SelectedIndex < indices.Length)
                return indices[tb_Device.SelectedIndex];
            else
                return tb_Device.Text;
        }

        void gcnProcess_Exited(object sender, EventArgs e)
        {
            Trace.WriteLine("Done");
            string last = gcnProcess.StandardError.ReadToEnd();
            Trace.WriteLine(last);
            Trace.WriteLine(gcnProcess.StandardOutput.ReadToEnd());
            last = last.Split('\n').Last();

            string message = "";
            switch((uint)gcnProcess.ExitCode)
            {
                case 0xC0000135:
                    message = "Code 0xC0000135: see the help";
                    break;
                case 0:
                    message = "Exited normally";
                    break;
                default:
                    message = String.Format("Exit {0:X}: {1}", gcnProcess.ExitCode, last);
                    break;
            }
            statusMessage.Text = message;

            btn_Start.Invoke(new MethodInvoker(delegate()
            {
                btn_Start.Enabled = true;
                btn_Stop.Enabled = false;
            }));
            gcnProcess.Close();
            gcnProcess = null;
        }

        private void btn_Start_Click(object sender, EventArgs e)
        {
            btn_Start.Enabled = false;
            btn_Stop.Enabled = true;

            if (gcnProcess != null && !gcnProcess.HasExited)
                return;     // Should not happen

            gcnProcess = new Process();
            gcnProcess.Exited += new EventHandler(gcnProcess_Exited);
            gcnProcess.EnableRaisingEvents = true;

            gcnProcess.StartInfo.Arguments = commandLine;
            Trace.WriteLine("gcnclient.exe " + commandLine);
            gcnProcess.StartInfo.FileName =
                System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\gcnclient.exe ";
            gcnProcess.StartInfo.RedirectStandardError = true;
            gcnProcess.StartInfo.RedirectStandardOutput = true;
            gcnProcess.StartInfo.UseShellExecute = false;
            gcnProcess.Start();
            Trace.WriteLine("Started at PID " + gcnProcess.Id.ToString());
        }

        private void btn_Stop_Click(object sender, EventArgs e)
        {
            if (gcnProcess == null || gcnProcess.HasExited)
                return;     // Should not happen

            gcnProcess.Kill();
            // Fires gcnProcess_Exited to re-enable start button
            gcnProcess.Close();
        }
    }
}
