﻿namespace gcnclientGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.tooltip = new System.Windows.Forms.ToolTip(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cb_Retry = new System.Windows.Forms.CheckBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Server = new System.Windows.Forms.TextBox();
            this.tb_ServerPort = new System.Windows.Forms.TextBox();
            this.tb_Device = new System.Windows.Forms.ComboBox();
            this.cmdLine = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_Start = new System.Windows.Forms.Button();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.tb_Port = new System.Windows.Forms.TextBox();
            this.tb_Hub = new System.Windows.Forms.ComboBox();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Virtual Hub";
            this.tooltip.SetToolTip(this.label1, "Virtual hub to connect to.  Case sensitive.\r\nYou may type any hub name, even if i" +
                    "t\'s not in the dropdown.");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Client Name";
            this.tooltip.SetToolTip(this.label2, "Name that identifies your client.\r\nExample: KermClient, MyschoolBridge");
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Metahub Host";
            this.tooltip.SetToolTip(this.label3, "Hostname or IP address of the metahub.\r\nThis normally doesn\'t need to change.\r\nDe" +
                    "fault: gcnhub.cemetech.net");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Server Port";
            this.tooltip.SetToolTip(this.label4, "Port to connect to on the server.\r\nDefault: 4295");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Device Type";
            this.tooltip.SetToolTip(this.label5, "How your calculator is connected to this computer.\r\nDirect USB: via the calculato" +
                    "r\'s USB port\r\nArduino: via an Arduino and the I/O port\r\nUSB HID: via the $10 bri" +
                    "dge and I/O port");
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Port";
            this.tooltip.SetToolTip(this.label6, "Serial port the device is connected to.\r\nOnly applies to Arduino devices.\r\nExampl" +
                    "e: COM3, /dev/ttyUSB0");
            // 
            // cb_Retry
            // 
            this.cb_Retry.AutoSize = true;
            this.cb_Retry.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cb_Retry.Checked = true;
            this.cb_Retry.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_Retry.Location = new System.Drawing.Point(45, 174);
            this.cb_Retry.Name = "cb_Retry";
            this.cb_Retry.Size = new System.Drawing.Size(176, 17);
            this.cb_Retry.TabIndex = 19;
            this.cb_Retry.Text = "Retry on communications failure";
            this.tooltip.SetToolTip(this.cb_Retry, "Uncheck to stop the client on communication error.\r\nLeave checked unless you have" +
                    " good reason to change it.");
            this.cb_Retry.UseVisualStyleBackColor = true;
            this.cb_Retry.CheckedChanged += new System.EventHandler(this.UpdateCmdLine);
            // 
            // tb_Name
            // 
            this.tb_Name.Location = new System.Drawing.Point(101, 41);
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(120, 20);
            this.tb_Name.TabIndex = 2;
            this.tb_Name.TextChanged += new System.EventHandler(this.UpdateCmdLine);
            // 
            // tb_Server
            // 
            this.tb_Server.Location = new System.Drawing.Point(101, 67);
            this.tb_Server.Name = "tb_Server";
            this.tb_Server.Size = new System.Drawing.Size(121, 20);
            this.tb_Server.TabIndex = 4;
            this.tb_Server.TextChanged += new System.EventHandler(this.UpdateCmdLine);
            // 
            // tb_ServerPort
            // 
            this.tb_ServerPort.Location = new System.Drawing.Point(101, 93);
            this.tb_ServerPort.Name = "tb_ServerPort";
            this.tb_ServerPort.Size = new System.Drawing.Size(121, 20);
            this.tb_ServerPort.TabIndex = 7;
            this.tb_ServerPort.TextChanged += new System.EventHandler(this.UpdateCmdLine);
            // 
            // tb_Device
            // 
            this.tb_Device.FormattingEnabled = true;
            this.tb_Device.Items.AddRange(new object[] {
            "Direct USB",
            "Arduino",
            "USB HID (\"$10 Bridge\")"});
            this.tb_Device.Location = new System.Drawing.Point(101, 121);
            this.tb_Device.Name = "tb_Device";
            this.tb_Device.Size = new System.Drawing.Size(121, 21);
            this.tb_Device.TabIndex = 10;
            this.tb_Device.TextChanged += new System.EventHandler(this.UpdateCmdLine);
            // 
            // cmdLine
            // 
            this.cmdLine.Location = new System.Drawing.Point(15, 210);
            this.cmdLine.Name = "cmdLine";
            this.cmdLine.Size = new System.Drawing.Size(210, 20);
            this.cmdLine.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Command line";
            // 
            // btn_Start
            // 
            this.btn_Start.Location = new System.Drawing.Point(15, 236);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(95, 23);
            this.btn_Start.TabIndex = 21;
            this.btn_Start.Text = "Start";
            this.btn_Start.UseVisualStyleBackColor = true;
            this.btn_Start.Click += new System.EventHandler(this.btn_Start_Click);
            // 
            // btn_Stop
            // 
            this.btn_Stop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Stop.Enabled = false;
            this.btn_Stop.Location = new System.Drawing.Point(130, 236);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(95, 23);
            this.btn_Stop.TabIndex = 22;
            this.btn_Stop.Text = "Stop";
            this.btn_Stop.UseVisualStyleBackColor = true;
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusMessage});
            this.statusStrip1.Location = new System.Drawing.Point(0, 293);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(236, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 17;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // statusMessage
            // 
            this.statusMessage.Name = "statusMessage";
            this.statusMessage.Size = new System.Drawing.Size(39, 17);
            this.statusMessage.Text = "Ready";
            // 
            // tb_Port
            // 
            this.tb_Port.Location = new System.Drawing.Point(101, 148);
            this.tb_Port.Name = "tb_Port";
            this.tb_Port.Size = new System.Drawing.Size(120, 20);
            this.tb_Port.TabIndex = 12;
            this.tb_Port.TextChanged += new System.EventHandler(this.UpdateCmdLine);
            // 
            // tb_Hub
            // 
            this.tb_Hub.FormattingEnabled = true;
            this.tb_Hub.Items.AddRange(new object[] {
            "IRCHub",
            "WebHub"});
            this.tb_Hub.Location = new System.Drawing.Point(101, 13);
            this.tb_Hub.Name = "tb_Hub";
            this.tb_Hub.Size = new System.Drawing.Size(121, 21);
            this.tb_Hub.TabIndex = 1;
            this.tb_Hub.TextChanged += new System.EventHandler(this.UpdateCmdLine);
            // 
            // Form1
            // 
            this.AcceptButton = this.btn_Start;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Stop;
            this.ClientSize = new System.Drawing.Size(236, 315);
            this.Controls.Add(this.cb_Retry);
            this.Controls.Add(this.tb_Hub);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btn_Stop);
            this.Controls.Add(this.btn_Start);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmdLine);
            this.Controls.Add(this.tb_Port);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tb_Device);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_ServerPort);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_Server);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_Name);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "GCNClient GUI";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolTip tooltip;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_Server;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_ServerPort;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox tb_Device;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox cmdLine;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_Start;
        private System.Windows.Forms.Button btn_Stop;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusMessage;
        private System.Windows.Forms.TextBox tb_Port;
        private System.Windows.Forms.ComboBox tb_Hub;
        private System.Windows.Forms.CheckBox cb_Retry;
    }
}

