﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace gcnclientGUI
{
    public partial class MainForm : Form
    {
        private string commandLine = "";
        private Process gcnProcess = null;

        public MainForm()
        {
            InitializeComponent();
            UpdateCmdLine(null, null);

            textControls = new Control[] {
                tb_Hub,
                tb_Name,
                tb_Server,
                tb_Port,
                tb_Device,
                tb_Port,
            };
        }

        private void UpdateCmdLine(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(String.Format("-n {0} ", tb_Hub.Text));
            sb.Append(String.Format("-l {0} ", tb_Name.Text));
            if (cb_Retry.Checked)
                sb.Append("-r ");

            sb.Append(String.Format("-d {0} ", TranslateDevice()));
            tb_Port.Enabled = TranslateDevice() == "arduino";
            if (tb_Port.Enabled)
                sb.Append(String.Format("-c {0} ", tb_Port.Text));

            if (tb_Server.Text != String.Empty)
                sb.Append(String.Format("-s {0} ", tb_Server.Text));

            if (tb_ServerPort.Text != String.Empty)
                sb.Append(String.Format("-p {0} ", tb_ServerPort.Text));

            commandLine = sb.ToString();
            cmdLine.Text = "gcnclient " + commandLine;

            bool acceptableToStart = tb_Hub.Text != String.Empty &&
                                     tb_Name.Text != String.Empty &&
                                     TranslateDevice() != String.Empty &&
                                     gcnProcess == null;
            if (TranslateDevice() == "arduino")
                acceptableToStart &= tb_Port.Text != String.Empty;
            btn_Start.Enabled = acceptableToStart;
        }

        private string TranslateDevice()
        {
            string[] indices = {"direct", "arduino", "usbhid"};
            if (tb_Device.SelectedIndex >= 0 && tb_Device.SelectedIndex < indices.Length)
                return indices[tb_Device.SelectedIndex];
            else
                return tb_Device.Text;
        }

        void gcnProcess_Exited(object sender, EventArgs e)
        {
            string message = "";
            switch((uint)gcnProcess.ExitCode)
            {
                case 0xC0000135:
                    message = "Code 0xC0000135: see the help";
                    break;
                case 0:
                    message = "Exited normally";
                    break;
                default:
                    message = String.Format("Exited with code {0:X}", gcnProcess.ExitCode);
                    break;
            }
            statusMessage.Text = message;

            btn_Start.Invoke(new MethodInvoker(delegate()
            {
                btn_Start.Enabled = true;
                btn_Stop.Enabled = false;
            }));
            gcnProcess.Close();
            gcnProcess = null;
        }

        private void btn_Start_Click(object sender, EventArgs e)
        {
            try
            {
                if (gcnProcess != null && !gcnProcess.HasExited)
                    return;     // Mostly impossible, just ignore the click.
            }
            catch (InvalidOperationException)
            {
                // This _should_ only happen when we hit the race where the user clicks "start" twice
                // very fast, so the process exists but hasn't been started.  Just give up, since it's
                // already starting.
                return;
            }

            gcnProcess = new Process();
            gcnProcess.Exited += new EventHandler(gcnProcess_Exited);
            gcnProcess.EnableRaisingEvents = true;

            gcnProcess.StartInfo.Arguments = commandLine;
            gcnProcess.StartInfo.FileName = Program.clientBinary;
                
            gcnProcess.StartInfo.RedirectStandardError = true;
            gcnProcess.StartInfo.RedirectStandardOutput = true;
            gcnProcess.StartInfo.UseShellExecute = false;
            gcnProcess.StartInfo.CreateNoWindow = true;

            try
            {
                gcnProcess.Start();
            }
            catch (Win32Exception)
            {
                statusMessage.Text = "Couldn't find gcnclient.exe";
                return;
            }

            if (cb_ShowOutput.Checked)
                new ClientOutput(gcnProcess).Show();
            btn_Start.Enabled = false;
            btn_Stop.Enabled = true;

        }

        private void btn_Stop_Click(object sender, EventArgs e)
        {
            if (gcnProcess == null || gcnProcess.HasExited)
                return;     // Should not happen

            gcnProcess.Kill();
            // Fires gcnProcess_Exited to re-enable start button
            gcnProcess.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new About().ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Text-based controls to serialize
        /// </summary>
        private Control[] textControls;

        private void saveConnectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Client configuration|*.txt";
            sfd.DefaultExt = "txt";
            sfd.AddExtension = true;
            if (sfd.ShowDialog() != DialogResult.OK)
                return;

            StreamWriter target = null;
            try
            {
                target = new StreamWriter(sfd.FileName);
                target.Write("# Connection configuration file generated by GCNClient GUI\n");
                target.Write("# Values are given in the same order they are shown in the GUI, one per line.\n");
                target.Write("# See http://www.taricorp.net/projects/gcnclient-gui/ for more information.\n");
                foreach (Control c in textControls)
                {
                    target.Write(c.Text);
                    target.Write('\n');
                }
                target.Write(cb_Retry.Checked);
                target.Write('\n');
                target.Write(cb_ShowOutput.Checked);
            }
            catch (IOException ex)
            {
                MessageBox.Show(this, "Unable to write file: " + ex.Message, "Write error");
            }
            finally
            {
                if (target != null)
                    target.Close();
            }
        }

        private void loadConnectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Client configuration|*.txt|All files|*.*";
            if (ofd.ShowDialog() != DialogResult.OK)
                return;

            StreamReader target = null;
            try
            {
                target = new StreamReader(ofd.FileName);
                string[] lines = target.ReadToEnd().Split('\n');
                lines = lines.Where(s => s.Length == 0 || s.TrimStart(new char[] { ' ', '\t' })[0] != '#').ToArray();
                int i;
                for (i = 0; i < textControls.Length; i++)
                {
                    textControls[i].Text = lines[i];
                }
                cb_Retry.Checked = bool.Parse(lines[i++]);
                cb_ShowOutput.Checked = bool.Parse(lines[i++]);
            }
            catch (IOException ex)
            {
                MessageBox.Show(this, "Unable to read file: " + ex.Message, "Read error");
            }
            finally
            {
                if (target != null)
                    target.Close();
            }
        }
    }
}
