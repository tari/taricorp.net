﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace gcnclientGUI
{
    static class Program
    {
        public static string clientBinary;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                clientBinary = args[0];
            }
            else
            {
                clientBinary = Path.GetDirectoryName(Application.ExecutablePath) + "\\gcnclient.exe";
            }
            if (!File.Exists(clientBinary))
                MessageBox.Show("Could not find gcnclient.exe!\n" +
                    "If not specified on the command line, it should be in the same directory as this program.",
                    "Client not found", MessageBoxButtons.OK, MessageBoxIcon.Error);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
