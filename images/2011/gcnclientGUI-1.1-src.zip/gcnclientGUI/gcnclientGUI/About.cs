﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace gcnclientGUI
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();

            Version v = Assembly.GetExecutingAssembly().GetName().Version;
            versionLabel.Text = String.Format("Version {0}.{1} build {2}", v.Major, v.Minor, v.Build);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.taricorp.net/projects/gcnclient-gui/");
        }
    }
}
