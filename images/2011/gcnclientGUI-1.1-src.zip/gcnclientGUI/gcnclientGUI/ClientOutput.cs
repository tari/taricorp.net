﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace gcnclientGUI
{
    public partial class ClientOutput : Form
    {
        private Process p;

        public ClientOutput(Process p)
        {
            this.p = p;
            p.ErrorDataReceived += new DataReceivedEventHandler(p_DataReceived);
            p.OutputDataReceived += new DataReceivedEventHandler(p_DataReceived);
            p.BeginErrorReadLine();
            p.BeginOutputReadLine();
            p.Exited += new EventHandler(p_Exited);

            InitializeComponent();

            this.Text = String.Format("GCNClient Output: PID {0}", p.Id);
        }

        // Subprocess exited.
        void p_Exited(object sender, EventArgs e)
        {
            outputBox.Invoke((MethodInvoker)delegate()
            {
                outputBox.AppendText(">Process exited.");
            });
        }

        /// <summary>
        /// Handles when data arrives from the target process.
        /// </summary>
        void p_DataReceived(object sender, DataReceivedEventArgs e)
        {
            outputBox.Invoke((MethodInvoker)delegate()
            {
                if (e.Data != null)
                    outputBox.AppendText(e.Data);
                outputBox.AppendText(Environment.NewLine);
            });
        }
    }
}
