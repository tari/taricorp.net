﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RXSCI_Calc
{
    public partial class MainForm : Form
    {
        private int B;
        private decimal PCLK;

        public MainForm()
        {
            InitializeComponent();
        }

        private void InputsChanged(object sender, EventArgs e)
        {
            B = (int)Selector_B.Value;
            PCLK = Selector_PCLK.Value;

            Outputs_Recalc();
        }

        private void Outputs_Recalc()
        {
            double PCLK = (double)this.PCLK;

            bool bestABCS = false;
            int bestN = 0;
            int bestCKS = 0;
            double bestError = double.MaxValue;

            for (int n = 0; n < 4; n++)
            {
                foreach (int ABCS_Mult in new int[] {32, 64})
                {
                    double N = PCLK * 1e6;
                    double divider = ABCS_Mult * B * Math.Pow(2, (2 * n) - 1);
                    N /= divider;
                    N -= 1;
                    N = Math.Round(N, 0);
                    // Latch N to valid 8-bit range
                    if (N < 0)
                        N = 0;
                    else if (N > 255)
                        N = 255;
                    // Find error for this N
                    double error = PCLK * 1e6;
                    error /= ABCS_Mult * B;
                    error /= Math.Pow(2, 2 * n - 1);
                    error /= N + 1;
                    error -= 1;

                    if (Math.Abs(error) < bestError)
                    {
                        bestABCS = ABCS_Mult == 32;
                        bestN = (int)N;
                        bestCKS = n;
                        bestError = error;
                    }
                }
            }

            Output_ABCS.Checked = bestABCS;
            Output_BRR.Text = bestN.ToString();
            Output_CKS.Text = bestCKS.ToString();
            Output_Error.Text = Math.Round((bestError * 100), 2).ToString();
        }

        private void Link_taricorp_net_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://taricorp.net/");
        }

    }

}
