﻿namespace RXSCI_Calc
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.Selector_B = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.Selector_PCLK = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Output_Error = new System.Windows.Forms.TextBox();
            this.Output_BRR = new System.Windows.Forms.TextBox();
            this.Output_CKS = new System.Windows.Forms.TextBox();
            this.Output_ABCS = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Link_taricorp_net = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.Selector_B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Selector_PCLK)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Selector_B
            // 
            this.Selector_B.Location = new System.Drawing.Point(79, 14);
            this.Selector_B.Maximum = new decimal(new int[] {
            2000000,
            0,
            0,
            0});
            this.Selector_B.Name = "Selector_B";
            this.Selector_B.Size = new System.Drawing.Size(97, 20);
            this.Selector_B.TabIndex = 4;
            this.Selector_B.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Selector_B.ValueChanged += new System.EventHandler(this.InputsChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Bit rate (bps)";
            // 
            // Selector_PCLK
            // 
            this.Selector_PCLK.DecimalPlaces = 2;
            this.Selector_PCLK.Location = new System.Drawing.Point(79, 35);
            this.Selector_PCLK.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.Selector_PCLK.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Selector_PCLK.Name = "Selector_PCLK";
            this.Selector_PCLK.Size = new System.Drawing.Size(97, 20);
            this.Selector_PCLK.TabIndex = 7;
            this.Selector_PCLK.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Selector_PCLK.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Selector_PCLK.ValueChanged += new System.EventHandler(this.InputsChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "PCLK (MHz)";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Selector_B);
            this.groupBox1.Controls.Add(this.Selector_PCLK);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(182, 62);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Targets";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.Output_Error);
            this.groupBox2.Controls.Add(this.Output_BRR);
            this.groupBox2.Controls.Add(this.Output_CKS);
            this.groupBox2.Controls.Add(this.Output_ABCS);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(12, 80);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(182, 109);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Settings";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Error %";
            // 
            // Output_Error
            // 
            this.Output_Error.Enabled = false;
            this.Output_Error.Location = new System.Drawing.Point(78, 84);
            this.Output_Error.MaxLength = 32;
            this.Output_Error.Name = "Output_Error";
            this.Output_Error.Size = new System.Drawing.Size(96, 20);
            this.Output_Error.TabIndex = 7;
            this.Output_Error.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Output_BRR
            // 
            this.Output_BRR.Enabled = false;
            this.Output_BRR.Location = new System.Drawing.Point(78, 37);
            this.Output_BRR.MaxLength = 3;
            this.Output_BRR.Name = "Output_BRR";
            this.Output_BRR.Size = new System.Drawing.Size(97, 20);
            this.Output_BRR.TabIndex = 6;
            this.Output_BRR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Output_CKS
            // 
            this.Output_CKS.Enabled = false;
            this.Output_CKS.Location = new System.Drawing.Point(78, 17);
            this.Output_CKS.MaxLength = 1;
            this.Output_CKS.Name = "Output_CKS";
            this.Output_CKS.Size = new System.Drawing.Size(97, 20);
            this.Output_CKS.TabIndex = 5;
            this.Output_CKS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Output_ABCS
            // 
            this.Output_ABCS.AutoSize = true;
            this.Output_ABCS.Enabled = false;
            this.Output_ABCS.Location = new System.Drawing.Point(121, 63);
            this.Output_ABCS.Name = "Output_ABCS";
            this.Output_ABCS.Size = new System.Drawing.Size(54, 17);
            this.Output_ABCS.TabIndex = 4;
            this.Output_ABCS.Text = "ABCS";
            this.Output_ABCS.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "BRR";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "CKS[1:0]";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(12, 196);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(182, 26);
            this.textBox1.TabIndex = 11;
            this.textBox1.Text = "RX62N/RX621 SCI bitrate calculator by Peter Marheine.";
            // 
            // Link_taricorp_net
            // 
            this.Link_taricorp_net.AutoSize = true;
            this.Link_taricorp_net.Location = new System.Drawing.Point(9, 225);
            this.Link_taricorp_net.Name = "Link_taricorp_net";
            this.Link_taricorp_net.Size = new System.Drawing.Size(96, 13);
            this.Link_taricorp_net.TabIndex = 12;
            this.Link_taricorp_net.TabStop = true;
            this.Link_taricorp_net.Text = "http://taricorp.net/";
            this.Link_taricorp_net.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Link_taricorp_net_LinkClicked);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(205, 244);
            this.Controls.Add(this.Link_taricorp_net);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "RX62x BRR Calc";
            ((System.ComponentModel.ISupportInitialize)(this.Selector_B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Selector_PCLK)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown Selector_B;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown Selector_PCLK;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox Output_ABCS;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Output_BRR;
        private System.Windows.Forms.TextBox Output_CKS;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Output_Error;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.LinkLabel Link_taricorp_net;

    }
}

